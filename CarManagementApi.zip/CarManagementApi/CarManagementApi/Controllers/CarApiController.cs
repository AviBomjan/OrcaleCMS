﻿using CarStockApiTask.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data.Common;

namespace CarStockApiTask.Controllers
{
    [Route("api/car")]
    [ApiController]
    public class CarApiController : ControllerBase
    {
        private readonly ApiDbContext _apiDbContext;
        private readonly IConfiguration _configuration;
        public CarApiController(ApiDbContext apiDbContext, IConfiguration configuration)
        {
            _apiDbContext = apiDbContext;
            _configuration = configuration;
        }
        //List all the cars in the table
        [HttpGet]
        [Route("Get-All-Car-List")]
        public async Task<IActionResult> GetAllCar()
        {
            var cars = await _apiDbContext.Cars.ToListAsync();
            return Ok(cars);
        }
        //Retrive the data of a specific car by id
        /*[HttpGet]
        [Route("Get-Car-By-Id/{carId}")]
        public async Task<IActionResult> GetCarById(int carId)
        {
            var car = await _apiDbContext.Cars.FindAsync(carId);
            return Ok(car);
        }*/
        //Add a new car to the table
        [HttpPost]
        [Route("Add-Car")]
        public async Task<IActionResult> AddCar(Cars car)
        {
            _apiDbContext.Cars.Add(car);
            await _apiDbContext.SaveChangesAsync();
            return Created($"/Get-Car-By-Id/{car.CarId}", car);
        }
        //Update the data of a specific car by id
        [HttpPut]
        [Route("Update-Car")]
        public async Task<IActionResult> UpdateCar(Cars carToUpdate)
        {
            _apiDbContext.Cars.Update(carToUpdate);
            await _apiDbContext.SaveChangesAsync();
            return NoContent();
        }
        //Delete a car from the table
        [HttpDelete]
        [Route("Delete-Car-By-Id/{carId}")]
        public async Task<IActionResult> DeleteCar(int carId)
        {
            var carToDelete = await _apiDbContext.Cars.FindAsync(carId);
            if (carToDelete == null)
            {
                return NotFound();
            }
            _apiDbContext.Cars.Remove(carToDelete);
            await _apiDbContext.SaveChangesAsync();
            return NoContent();
        }
        //Search for a car from the table with make and model
        [HttpGet]
        [Route("Search-Car-By-Make-And-Model")]
        public async Task<IActionResult> SearchCar(string Makes, string Models)
        {
            String searchCarSQL = "SELECT * FROM [Car].[dbo].[Cars] WHERE Make = @Makes AND Model = @Models;";
            string connectionString = _configuration.GetConnectionString("DbConnection");
            string result = "";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(searchCarSQL, connection);
                command.Parameters.AddWithValue("@Makes", Makes);
                command.Parameters.AddWithValue("@Models", Models);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    try
                    {
                        while (reader.Read())
                        {
                            //Read The CarId, Make, Model, Year, Stock from Table
                            result += "Id: " + reader.GetInt32(0) + ". Make: " + reader.GetString(1) + ". Model: " + reader.GetString(2) + ". Year: " + reader.GetInt32(3) + ". Stock: " + reader.GetInt32(4) + ".";
                        }
                    }
                    finally
                    {
                        reader.Close();
                    }
                }
                else
                {
                    Console.WriteLine("No cars found.");
                }
            }
            //Return the searched car
            return Ok(result);
        }


    }
}
