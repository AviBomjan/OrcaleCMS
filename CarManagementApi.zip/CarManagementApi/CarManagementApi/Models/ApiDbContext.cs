﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace CarStockApiTask.Models
{
    public class ApiDbContext : DbContext
    {
        public ApiDbContext(DbContextOptions<ApiDbContext> options) : base(options)
        {

        }
        public DbSet<Cars> Cars { get; set; }
    }
}
