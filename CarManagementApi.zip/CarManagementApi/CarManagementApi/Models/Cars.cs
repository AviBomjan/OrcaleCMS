﻿using System.ComponentModel.DataAnnotations;

namespace CarStockApiTask.Models
{
    public class Cars
    {
        //Primary identifier of the car
        [Key]
        public int CarId { get; set; }
        //Make
        public string Make { get; set; }
        //Model
        public string Model { get; set; }
        //Year
        public int Year { get; set; }
        //Stock
        public int Stock { get; set; }
    }
}
